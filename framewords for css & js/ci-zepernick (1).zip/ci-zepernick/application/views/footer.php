		
		      	</div>
		      </div> <!-- Ends content block -->
		   </div> <!-- End content row -->
		   
		</div> <!-- Ends container-fluid div -->
		<div id="push"></div>
	</div> <!-- Ends the wrap div -->
		
		<div id="footer">
		      <div class="container-fluid">
		      		<div class="row">
		      			<div class="col-md-12">
		      				<div class="center-block text-center">Copyright (c) 2015 Paul Zepernick</div>
		      			</div>
		      		</div>
		        	
		      </div>
	    </div>
	</body>
</html>