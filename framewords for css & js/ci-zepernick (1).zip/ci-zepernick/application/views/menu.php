<nav class="navbar navbar-default">
       <div class="container-fluid">
	      <div class="collapse navbar-collapse">
	            <ul class="nav navbar-nav">
	               <div class="navbar-header">
				        <a class="navbar-brand" href="#">
				            CI-Zepernick
				        </a>
				    </div>
	               <?php echo bootMenuItem('', 'DataTables') ?>
	            </ul>
	            <ul class="nav navbar-nav navbar-right">
	            	<li><a href="http://www.paulzepernick.com/ci-zepernick.zip">Download App</a></li>
	           	</ul>
	           	
	       </div>
       	</div>
 </nav>
